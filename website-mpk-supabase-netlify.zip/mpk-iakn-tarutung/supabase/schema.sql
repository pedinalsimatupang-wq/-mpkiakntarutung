-- Jalankan seluruh file ini melalui Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.admin_users (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.berita (
 id uuid primary key default gen_random_uuid(),
 judul text not null check (char_length(judul) between 1 and 180),
 ringkasan text not null default '', isi text not null default '',
 kategori text not null default 'Kegiatan', tanggal_publikasi date, gambar_url text,
 status text not null default 'draft' check(status in ('draft','published')),
 created_by uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.dosen (
 id uuid primary key default gen_random_uuid(), nama text not null, gelar text, jabatan text,
 bidang_keahlian text, foto_url text, email text, urutan integer not null default 0,
 published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.kurikulum (
 id uuid primary key default gen_random_uuid(), semester integer not null check(semester between 1 and 14),
 kode_mata_kuliah text, nama_mata_kuliah text not null, sks integer not null default 0 check(sks between 0 and 20),
 deskripsi text, published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.pengumuman (
 id uuid primary key default gen_random_uuid(), judul text not null, isi text not null default '',
 tanggal_publikasi date, tautan_url text, status text not null default 'draft' check(status in ('draft','published')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.profil_prodi (
 id integer primary key default 1 check(id=1), nama_prodi text not null default 'Program Studi Manajemen Pendidikan Kristen',
 sejarah text not null default '', visi text not null default '', misi jsonb not null default '[]'::jsonb,
 tujuan text not null default '', profil_lulusan jsonb not null default '[]'::jsonb, akreditasi text not null default '', updated_at timestamptz not null default now()
);
create or replace function public.is_mpk_admin() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.admin_users a where a.user_id=(select auth.uid())); $$;
revoke all on function public.is_mpk_admin() from public;
grant execute on function public.is_mpk_admin() to anon, authenticated;
alter table public.admin_users enable row level security;
alter table public.berita enable row level security;
alter table public.dosen enable row level security;
alter table public.kurikulum enable row level security;
alter table public.pengumuman enable row level security;
alter table public.profil_prodi enable row level security;
drop policy if exists "admin self read" on public.admin_users;
create policy "admin self read" on public.admin_users for select to authenticated using(user_id=(select auth.uid()));
drop policy if exists "published news read" on public.berita;
create policy "published news read" on public.berita for select to anon,authenticated using(status='published' or public.is_mpk_admin());
drop policy if exists "admin insert news" on public.berita;
create policy "admin insert news" on public.berita for insert to authenticated with check(public.is_mpk_admin());
drop policy if exists "admin update news" on public.berita;
create policy "admin update news" on public.berita for update to authenticated using(public.is_mpk_admin()) with check(public.is_mpk_admin());
drop policy if exists "admin delete news" on public.berita;
create policy "admin delete news" on public.berita for delete to authenticated using(public.is_mpk_admin());
drop policy if exists "published faculty read" on public.dosen;
create policy "published faculty read" on public.dosen for select to anon,authenticated using(published or public.is_mpk_admin());
drop policy if exists "admin manage faculty" on public.dosen;
create policy "admin manage faculty" on public.dosen for all to authenticated using(public.is_mpk_admin()) with check(public.is_mpk_admin());
drop policy if exists "published curriculum read" on public.kurikulum;
create policy "published curriculum read" on public.kurikulum for select to anon,authenticated using(published or public.is_mpk_admin());
drop policy if exists "admin manage curriculum" on public.kurikulum;
create policy "admin manage curriculum" on public.kurikulum for all to authenticated using(public.is_mpk_admin()) with check(public.is_mpk_admin());
drop policy if exists "published announcements read" on public.pengumuman;
create policy "published announcements read" on public.pengumuman for select to anon,authenticated using(status='published' or public.is_mpk_admin());
drop policy if exists "admin manage announcements" on public.pengumuman;
create policy "admin manage announcements" on public.pengumuman for all to authenticated using(public.is_mpk_admin()) with check(public.is_mpk_admin());
drop policy if exists "profile public read" on public.profil_prodi;
create policy "profile public read" on public.profil_prodi for select to anon,authenticated using(true);
drop policy if exists "admin manage profile" on public.profil_prodi;
create policy "admin manage profile" on public.profil_prodi for all to authenticated using(public.is_mpk_admin()) with check(public.is_mpk_admin());
insert into public.profil_prodi(id) values(1) on conflict do nothing;
create or replace function public.set_updated_at() returns trigger language plpgsql set search_path='' as $$ begin new.updated_at=now(); return new; end; $$;
do $$ declare t text; begin foreach t in array array['berita','dosen','kurikulum','pengumuman','profil_prodi'] loop execute format('drop trigger if exists set_updated_at on public.%I',t); execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()',t); end loop; end $$;
-- Setelah membuat admin di Authentication > Users, ganti UUID di query berikut:
-- insert into public.admin_users(user_id) values ('UUID-USER-ADMIN') on conflict do nothing;
