# Website MPK IAKN Tarutung — React + Supabase + Netlify

Starter ini menghubungkan login admin melalui Supabase Auth dan CRUD berita ke database PostgreSQL Supabase. Tabel dosen, kurikulum, pengumuman, dan profil disiapkan di SQL, tetapi formulir CRUD modul tersebut masih perlu dibuat.

## A. Buat proyek Supabase
1. Buat akun/proyek di https://supabase.com/ .
2. Buka SQL Editor, jalankan seluruh `supabase/schema.sql`.
3. Buka Project Settings > API dan salin Project URL serta publishable/anon key. Jangan pernah memakai service_role/secret key di React.

## B. Buat akun admin dengan aman
1. Buka Supabase Authentication > Users > Add user. Buat akun email dan password kuat.
2. Salin UUID user.
3. Jalankan di SQL Editor (ganti UUID):
   ```sql
   insert into public.admin_users(user_id) values ('UUID-USER-ADMIN') on conflict do nothing;
   ```
4. Jangan mengaktifkan pendaftaran admin publik. Hanya pemilik proyek yang boleh mengubah daftar admin.

## C. Konfigurasi lokal
1. Salin `.env.example` menjadi `.env.local`.
2. Isi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY`.
3. Jalankan `npm install`, lalu `npm run dev`.
4. Buka URL yang ditampilkan Vite. Jangan commit `.env.local` ke GitHub.

## D. Deploy Netlify dari GitHub
1. Commit isi proyek ini ke repo GitHub yang sudah ada (backup versi lama dahulu).
2. Di https://app.netlify.com/ pilih Add new site > Import an existing project, pilih repo.
3. Build command `npm run build`, publish directory `dist` (juga di `netlify.toml`).
4. Di Netlify Site configuration > Environment variables, tambahkan `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY`. Trigger deploy ulang.
5. Di Supabase Authentication > URL Configuration, masukkan domain Netlify ke URL yang diizinkan sesuai kebutuhan.

## E. Fitur dan keamanan
- Berita dapat ditambah, diedit, dihapus, disimpan permanen, dan dipublikasikan dari dashboard admin.
- Pengunjung hanya membaca berita `published`; draft hanya terlihat oleh admin.
- Dashboard memeriksa UUID akun pada `admin_users`. RLS policies mengamankan tabel.
- Realtime subscription dipakai untuk perubahan berita saat dashboard admin terbuka; jika ingin memastikan realtime aktif, aktifkan tabel `berita` di Database > Publications/Replication. Pengunjung yang membuka halaman baru mengambil berita terkini dari database.
- `VITE_` variables menjadi bagian dari bundle browser. Publishable/anon key boleh berada di browser jika RLS benar; jangan pernah mengekspos service_role, database password, atau secret key.
- SQL menyiapkan tabel `dosen`, `kurikulum`, `pengumuman`, dan `profil_prodi`, tetapi UI CRUD modul tersebut belum selesai.
- Berita memakai URL gambar opsional; upload gambar memerlukan Supabase Storage dan policies tambahan.
- Isi profil, visi-misi, akreditasi, nama dosen, kurikulum, kontak, dan tautan PMB wajib diverifikasi dari sumber resmi sebelum publikasi.
